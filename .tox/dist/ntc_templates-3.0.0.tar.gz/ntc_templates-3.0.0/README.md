# loxi-ntc-template
Run for test & build

```
$ sudo tox
```

Run just test

```
$ python -m pytest -v
```


