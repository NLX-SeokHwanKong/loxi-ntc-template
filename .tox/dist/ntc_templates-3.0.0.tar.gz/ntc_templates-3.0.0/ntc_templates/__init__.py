"""ntc_templates - Parse raw output from network devices and return structured data."""

__version__ = "3.0.0"
