# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['ntc_templates']

package_data = \
{'': ['*'], 'ntc_templates': ['templates/*', 'templates_backup/*']}

install_requires = \
['textfsm>=1.1.0,<2.0.0']

setup_kwargs = {
    'name': 'ntc-templates',
    'version': '3.0.0',
    'description': "TextFSM Templates for Network Devices, and Python wrapper for TextFSM's CliTable.",
    'long_description': '# loxi-ntc-template\nRun for test & build\n\n```\n$ sudo tox\n```\n\nRun just test\n\n```\n$ python -m pytest -v\n```\n\n\n',
    'author': 'Network to Code',
    'author_email': 'info@networktocode.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/networktocode/ntc-templates',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
